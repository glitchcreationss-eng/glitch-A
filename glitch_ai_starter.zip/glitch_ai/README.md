# GLITCH AI - Guerrilla Marketing Generator

## Setup

1. Install Python
2. Install Ollama
3. Run:

```bash
ollama pull mistral
```

4. Install packages:

```bash
pip install -r requirements.txt
```

5. Start the website:

```bash
python app.py
```

6. Open:

```text
http://127.0.0.1:5000
```

## Features

- Guerrilla marketing ideas
- Big ad script generation
- Malayalam + English hooks
- Strategy generation
- Download output as TXT