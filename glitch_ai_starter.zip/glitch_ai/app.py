from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import subprocess

app = Flask(__name__, static_folder="static")
CORS(app)

def generate_with_ollama(prompt: str) -> str:
    try:
        result = subprocess.run(
            ["ollama", "run", "mistral", prompt],
            capture_output=True,
            text=True,
            timeout=120
        )
        if result.returncode != 0:
            return "Ollama error: " + result.stderr
        return result.stdout.strip()
    except FileNotFoundError:
        return "Ollama is not installed. Install Ollama and run: ollama pull mistral"
    except subprocess.TimeoutExpired:
        return "AI generation timed out. Try a shorter prompt."

@app.route("/")
def home():
    return send_from_directory("static", "index.html")

@app.route("/generate", methods=["POST"])
def generate():
    data = request.get_json(force=True)

    product = data.get("product", "")
    audience = data.get("audience", "")
    location = data.get("location", "")
    budget = data.get("budget", "")
    language = data.get("language", "English")

    prompt = f"""
You are GLITCH AI, a bold guerrilla marketing strategist.

Create a complete marketing output for this product/service:

Product/Service: {product}
Target Audience: {audience}
Location: {location}
Budget: {budget}
Language: {language}

Give output in this format:

1. BRAND POSITIONING
2. 5 CREATIVE GUERRILLA MARKETING IDEAS
3. BEST PUBLIC STUNT IDEA
4. STEP-BY-STEP EXECUTION PLAN
5. INSTAGRAM REEL SCRIPT 30 SECONDS
6. POSTER COPY
7. 10 VIRAL HOOK LINES
8. MALAYALAM LOCAL STYLE HOOKS
9. LOW BUDGET STRATEGY
10. CALL TO ACTION

Make it practical, viral, emotional, and suitable for local business marketing.
"""

    output = generate_with_ollama(prompt)
    return jsonify({"output": output})

if __name__ == "__main__":
    app.run(debug=True)